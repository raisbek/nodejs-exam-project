import { PrismaClient} from "@prisma/client"
const prisma = new PrismaClient()

 export  class liderService{
   async allLiders(){
        return prisma.lider.findMany()
    }
     create(name,job,age){
        return prisma.lider.create({
            data:{
                name,
                job,
                age
            }
        })
    }
     update(id,name,job,age){
        return prisma.lider.update({
            data:{
                name,
                job,
                age
            },
            where:{
                id
            }
          
        })
    }
    
   delete(id){
        return prisma.lider.delete({
            where:{
                id
            }
        })
    }

}