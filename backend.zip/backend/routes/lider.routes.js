import { Router } from "express";
import  {liderService}  from "../service/lider.service.js"

const router = Router() 


router.get("/liders", async (req,res) => {
 try{
    let lider = await  liderService.allliders()
    res.send(lider)
 }
 catch(err){
    res.status(404).send("NO NO NO")
 }
})

router.post("/liders", (req,res) =>{
    try{
        let {name,job,age} = req.body
        liderService.create(name,job,age)
        res.sendStatus(201)
    }
    catch(err){
        res.status(404).send("NO NO NO")
    }
})
router.put('/liders/:id', (req,res) => {
    try{
        let {name,job,age} = req.body
        const id = req.params.id
        liderService.update(id,name,job,age)
        res.send("Updated")
    }
    catch(err){
        res.status(404).send("NO NO NO")
    }
})
router.delete("/liders/:id", (req,res) =>{
    try{
        const id = req.params.id
        liderService.delete(id)
        res.send("Delete")

    }
    catch(err){
        res.status(404).send("NO NO NO")
    } 
})
export default router